package com.example.testproject.classifier;

public enum Device {
    CPU,
    NNAPI,
    GPU
};
